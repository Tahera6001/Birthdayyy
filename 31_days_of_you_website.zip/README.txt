31 DAYS OF YOU — FREE WEBSITE

Files:
- index.html — the complete website. No server/database required.

HOW TO USE:
1. Open index.html in a browser to preview it.
2. To personalize it further, edit the text inside the `surprises` object in index.html.
3. Replace/add photos or videos wherever you want by editing the HTML.
4. For a free public link, upload index.html to a static hosting service such as GitHub Pages, Netlify, or Cloudflare Pages.

IMPORTANT:
The countdown is set for October 5, 2026 and uses India time (IST).
The website currently has the dates you gave me:
- His nickname: Mere Laddoo Gopal / Pandaa
- Birthday: October 5
- Relationship date: May 7
- Favourite colour: White
- Songs: Maula Mere Maula, Tum Hi Ho
- Favourite things: Mummy, biryani, Diet Coke
- Inside joke: ₹2 lakh pending
